"use strict"
let modal = document.getElementById("myModal"),
    btn = document.querySelectorAll("button"),
    span = document.getElementsByClassName("close")[0],
    pragreph_problem = document.getElementById("probl"),
    MyForm = document.getElementsByTagName("form"),
    BtnLang = document.getElementById("langage");

btn[0].onclick = () => {
    try {
        if (MyForm[0].children[0].value == "" && MyForm[0].children[1].value == "") throw "Choose the Time";
        if (MyForm[0].children[0].value == "") throw "Choose the Hour";
        if (MyForm[0].children[1].value == "") throw "Choose the Min";
        if (MyForm[0].children[0].value != "" && MyForm[0].children[1].value != "") throw true;
    } catch (error) {
        if (error === true) {
            calc(Number(MyForm[0].children[0].value), Number(MyForm[0].children[1].value), MyForm[0].children[2].value);
            modal.style.display = "block";
        } else
        // time
        if (error === "Choose the Time" && BtnLang.textContent == "AR") {
            alert("Choose the Time");
        } else if (error === "Choose the Time" && BtnLang.textContent == "EN") {
            alert("اختر الوقت");
        }
        // hours
        if (error === "Choose the Hour" && BtnLang.textContent == "AR") {
            alert("Choose the Hour");
        } else if (error === "Choose the Hour" && BtnLang.textContent == "EN") {
            alert("اختر الساعة");
        }
        // minuts
        if (error === "Choose the Min" && BtnLang.textContent == "AR") {
            alert("Choose the Min");
        } else if (error === "Choose the Min" && BtnLang.textContent == "EN") {
            alert("اختر الدقيقة");
        }
    } finally {
        MyForm[0].children[0].value = "";
        MyForm[0].children[1].value = "";
        MyForm[0].children[2].value = "am";
    }
}
btn[1].onclick = () => {
    try {
        if (MyForm[1].children[0].value == "" && MyForm[1].children[1].value == "") throw "Choose the Time";
        if (MyForm[1].children[0].value == "") throw "Choose the Hour ";
        if (MyForm[1].children[1].value == "") throw "Choose the Min";
        if (MyForm[1].children[0].value != "" && MyForm[1].children[1].value != "") throw true;
    } catch (error) {
        if (error === true) {
            calc_plus(Number(MyForm[1].children[0].value), Number(MyForm[1].children[1].value), MyForm[1].children[2].value);
            modal.style.display = "block";
        } else
            alert(error);
    } finally {
        MyForm[1].children[0].value = "";
        MyForm[1].children[1].value = "";
        MyForm[1].children[2].value = "am";
    }
}

span.onclick = () => {
    modal.style.display = "none";
}

window.onclick = (event) => {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
btn[2].onclick = () => {
    pragreph_problem.classList.remove("height_0");
    pragreph_problem.classList.add("height_auto");
    btn[2].style.display = "none"
}

function calc(H, M, A_P) {
    var Min = 30,
        Hour = 4;
    H = H - Hour;
    M = M - Min;
    if (M < 0) {
        H--;
        M = 60 + M;
    }
    if (H < 0) {
        H = 12 + H;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    var a = mois13Hour(H, M, A_P);
    var b = mois3Hour(H, M, A_P);
    var c = mois43Hour(H, M, A_P);
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    if (BtnLang.textContent == "AR")
        modal.children[0].children[1].textContent = `You should go to bed at one of the following times:`;
    else
        modal.children[0].children[1].textContent = `يجب أن تنام في إحدى الأوقات التالية:`;
    modal.children[0].children[2].textContent = `${H} : ${M} ${A_P}`;
    modal.children[0].children[3].textContent = `${a}`;
    modal.children[0].children[4].textContent = `${b}`;
    modal.children[0].children[5].textContent = `${c}`;
}

function mois13Hour(H, M, A_P) {
    var Min = 30,
        Hour = 1;
    H = H - Hour;
    M = M - Min;
    if (M < 0) {
        H--;
        M = 60 + M;
    }
    if (H < 0) {
        H = 12 + H;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    return `${H} : ${M} ${A_P}`;
}

function mois3Hour(H, M, A_P) {
    var Min = 0,
        Hour = 3;
    H = H - Hour;
    M = M - Min;
    if (M < 0) {
        H--;
        M = 60 + M;
    }
    if (H < 0) {
        H = 12 + H;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    return `${H} : ${M} ${A_P}`;
}

function mois43Hour(H, M, A_P) {
    var Min = 30,
        Hour = 4;
    H = H - Hour;
    M = M - Min;
    if (M < 0) {
        H--;
        M = 60 + M;
    }
    if (H < 0) {
        H = 12 + H;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    return `${H} : ${M} ${A_P}`;
}

function calc_plus(H, M, A_P) {
    var Min = 30,
        Hour = 4;
    H = H + Hour;
    M = M + Min;
    if (M > 60) {
        H++;
        M = M - 60;
    }
    if (M == 60) {
        H++;
        M = 0;
    }
    if (H > 12) {
        H = H - 12;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    var a = plus13Hour(H, M, A_P);
    var b = plus3Hour(H, M, A_P);
    var c = plus43Hour(H, M, A_P);
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    if (BtnLang.textContent == "AR")
        modal.children[0].children[1].textContent = `You should wake up at one of the following times:`;
    else
        modal.children[0].children[1].textContent = `يجب أن تستيقظ في إحدى الأوقات التالية:`;
    modal.children[0].children[5].textContent = `${c}`;
    modal.children[0].children[4].textContent = `${b}`;
    modal.children[0].children[3].textContent = `${a}`;
    modal.children[0].children[2].textContent = `${H} : ${M} ${A_P}`;
}

function plus13Hour(H, M, A_P) {
    var Min = 30,
        Hour = 1;
    H = H + Hour;
    M = M + Min;
    if (M > 60) {
        H++;
        M = M - 60;
    }
    if (M == 60) {
        H++;
        M = 0;
    }
    if (H > 12) {
        H = H - 12;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    return `${H} : ${M} ${A_P}`;
}

function plus3Hour(H, M, A_P) {
    var Min = 0,
        Hour = 3;
    H = H + Hour;
    M = M + Min;
    if (M > 60) {
        H++;
        M = M - 60;
    }
    if (M == 60) {
        H++;
        M = 0;
    }
    if (H > 12) {
        H = H - 12;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    return `${H} : ${M} ${A_P}`;
}

function plus43Hour(H, M, A_P) {
    var Min = 30,
        Hour = 4;
    H = H + Hour;
    M = M + Min;
    if (M > 60) {
        H++;
        M = M - 60;
    }
    if (M == 60) {
        H++;
        M = 0;
    }
    if (H > 12) {
        H = H - 12;
        if (A_P == "am")
            A_P = "pm";
        else
            A_P = "am";
    }
    if (M === 0)
        M = "00";
    if (M === 5)
        M = "05";
    if (H === 0)
        H = "00";
    return `${H} : ${M} ${A_P}`;
}